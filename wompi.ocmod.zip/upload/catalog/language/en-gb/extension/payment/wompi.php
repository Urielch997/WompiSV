<?php
// Text
$_['text_title'] = 'Tarjeta de Credito /Debito (Wompi)';